import pandapower as pp
import pandapower.plotting as plot
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.collections import LineCollection, PatchCollection
from pandapower.pypower.makeYbus import makeYbus
import pandas as pd
import numpy as np
import time
import os

# Alvaro, Domaboc, Orengo
print("=== PANDAPOWER NEWTON–RAPHSON POWER FLOW TEST ===")

# ------------------------------
#     Create empty network
# ------------------------------
net = pp.create_empty_network()

# ------------------------------
#      Loading csv files
# ------------------------------
std_types_df    = pd.read_csv("std_types.csv")
buses_df        = pd.read_csv("buses.csv")
transformers_df = pd.read_csv("transformers.csv")
loads_df        = pd.read_csv("loads.csv")
gens_df         = pd.read_csv("gens.csv")
shunts_df       = pd.read_csv("shunts.csv")
lines_df        = pd.read_csv("lines.csv")
ext_grid_df     = pd.read_csv("ext_grid.csv")
gen_costs_df    = pd.read_csv("gen_costs.csv")
ext_costs_df    = pd.read_csv("ext_grid_costs.csv")

HAS_3W = os.path.exists("std_types_3w.csv") and os.path.exists("transformers_3w.csv")
if HAS_3W:
    std_types_3w_df = pd.read_csv("std_types_3w.csv")
    transformers_3w_df = pd.read_csv("transformers_3w.csv")

# ------------------------------
#     Transformer 2w
# ------------------------------
for i, row in std_types_df.iterrows():
    pp.create_std_type(net, {
        "sn_mva":       row["sn_mva"],
        "vn_hv_kv":     row["vn_hv_kv"],
        "vn_lv_kv":     row["vn_lv_kv"],
        "vk_percent":   row["vk_percent"],
        "vkr_percent":  row["vkr_percent"],
        "pfe_kw":       row["pfe_kw"],
        "i0_percent":   row["i0_percent"],
        "shift_degree": row["shift_degree"]
    }, name=row["name"], element="trafo")

# ------------------------------
#     Transformer 3w
# ------------------------------
if HAS_3W:
    for i, row in std_types_3w_df.iterrows():
        pp.create_std_type(net, {
            "sn_hv_mva":       row["sn_hv_mva"],
            "sn_mv_mva":       row["sn_mv_mva"],
            "sn_lv_mva":       row["sn_lv_mva"],
            "vn_hv_kv":        row["vn_hv_kv"],
            "vn_mv_kv":        row["vn_mv_kv"],
            "vn_lv_kv":        row["vn_lv_kv"],
            "vk_hv_percent":   row["vk_hv_percent"],
            "vk_mv_percent":   row["vk_mv_percent"],
            "vk_lv_percent":   row["vk_lv_percent"],   
            "vkr_hv_percent":  row["vkr_hv_percent"],
            "vkr_mv_percent":  row["vkr_mv_percent"],
            "vkr_lv_percent":  row["vkr_lv_percent"],
            "pfe_kw":          row["pfe_kw"],
            "i0_percent":      row["i0_percent"],
            "shift_mv_degree": row["shift_mv_degree"],
            "shift_lv_degree": row["shift_lv_degree"],
        }, name=row["name"], element="trafo3w")
    

# ------------------------------
#     Bus
# ------------------------------
for i, row in buses_df.iterrows():
    pp.create_bus(net, vn_kv=row["vn_kv"], name=row["name"])

bus_index = {name: idx for idx, name in net.bus["name"].items()}

# ------------------------------
#     Bus Voltage Limits, PGC
# ------------------------------
net.bus["min_vm_pu"] = 0.95
net.bus["max_vm_pu"] = 1.05

# ------------------------------
#     Transformer 2w
# ------------------------------
for i, row in transformers_df.iterrows():
    pp.create_transformer(net,
        hv_bus=bus_index[row["hv_bus"]],
        lv_bus=bus_index[row["lv_bus"]],
        std_type=row["std_type"],
        name=row["name"])
    
# ------------------------------
#     Transformer 3w
# ------------------------------
if HAS_3W:
    for i, row in transformers_3w_df.iterrows():
        pp.create_transformer3w(net,
            hv_bus=bus_index[row["hv_bus"]],
            mv_bus=bus_index[row["mv_bus"]],
            lv_bus=bus_index[row["lv_bus"]],
            std_type=row["std_type"],
            name=row["name"])

# ------------------------------
#     Load
# ------------------------------
for i, row in loads_df.iterrows():
    pp.create_load(net,
        bus=bus_index[row["bus"]],
        p_mw=row["p_mw"],
        name=row["name"])

# ------------------------------
#     Generators
# ------------------------------
for i, row in gens_df.iterrows():
    pp.create_gen(net,
        bus=bus_index[row["bus"]],
        p_mw=row["p_mw"],
        name=row["name"])

# ------------------------------
#     Shunt
# ------------------------------
for i, row in shunts_df.iterrows():
    pp.create_shunt(net,
        bus=bus_index[row["bus"]],
        q_mvar=row["q_mvar"],
        name=row["name"])

# ------------------------------
#     Line
# ------------------------------
for i, row in lines_df.iterrows():
    pp.create_line_from_parameters(net,
        from_bus=bus_index[row["from_bus"]],
        to_bus=bus_index[row["to_bus"]],
        length_km=row["length_km"],
        r_ohm_per_km=row["r_ohm_per_km"],
        x_ohm_per_km=row["x_ohm_per_km"],
        c_nf_per_km=row["c_nf_per_km"],
        max_i_ka=row["max_i_ka"],
        name=row["name"])

net.line["max_loading_percent"] = 100

# ------------------------------
#     Ext Grid
# ------------------------------
for i, row in ext_grid_df.iterrows():
    pp.create_ext_grid(net,
        bus=bus_index[row["bus"]],
        vm_pu=row["vm_pu"],
        name=row["name"])

net.trafo["max_loading_percent"] = 100

# ------------------------------
#    Add Bus Coordinates for SLD
# ------------------------------
coords_df = pd.read_csv("coords.csv")
coords = {bus_index[row["bus"]]: (row["x"], row["y"]) for i, row in coords_df.iterrows()}

net.bus_geodata = pd.DataFrame(columns=['x', 'y'], dtype=float)
for bus in net.bus.index:
    if bus in coords:
        x, y = coords[bus]
        net.bus_geodata.loc[bus] = [x, y]
    else:
        net.bus_geodata.loc[bus] = [0.0, 0.0]
net.bus_geodata = net.bus_geodata.fillna(0.0)

# ------------------------------
#    Run Power Flow (Newton-Raphson)
# ------------------------------
print("\nRunning Newton–Raphson Power Flow...\n")

start_time = time.time()

pp.runpp(net,
         algorithm='nr',
         init='auto',
         calculate_voltage_angles=True,
         tolerance_mva=1e-6,
         max_iteration=10,
         numba=True,
         enforce_q_lims=True)

convergence_time = time.time() - start_time

print("\nNewton–Raphson Power Flow Converged!")
print(f"Convergence Time: {convergence_time:.6f} seconds")

# ------------------------------
#    Display Results
# ------------------------------
print("\n=== BUS VOLTAGE RESULTS (p.u.) ===")
print(net.res_bus[["vm_pu", "va_degree"]])

print("\n=== LINE FLOW RESULTS ===")
print(net.res_line[["loading_percent", "p_from_mw", "q_from_mvar", "p_to_mw", "q_to_mvar"]])

print("\n=== POWER FLOW METHOD: Newton–Raphson ===")

print("\n=== RUNNING OPF WITH WESM PWL COSTS ===")

# ------------------------------
# Load CSV files
# ------------------------------
gen_df = pd.read_csv("gen_costs.csv")
ext_df = pd.read_csv("ext_grid_costs.csv")

gen_lookup = gen_df.set_index("name").to_dict(orient="index")
ext_lookup = ext_df.set_index("name").to_dict(orient="index")

# ------------------------------
# Generator PWL costs
# ------------------------------
for i in net.gen.index:
    name = net.gen.loc[i, "name"]

    if name not in gen_lookup:
        raise ValueError(f"Generator '{name}' not found in CSV")

    row = gen_lookup[name]

    # max_p_mw is currently the actual dispatch to completely replicate WESM
    # if we want to use the dependable capacity instead just make the one below True
    # qmin and qmax are based on dependable capacity tho, since actual dispatch contains zeros
    USE_DEP_CAPACITY = True


    # Limits
    net.gen.loc[i, "min_p_mw"] = row["min_p_mw"]
    net.gen.loc[i, "max_p_mw"] = row["dep_capacity"] if USE_DEP_CAPACITY else row["max_p_mw"]
    net.gen.loc[i, "min_q_mvar"] = row["min_q_mvar"]
    net.gen.loc[i, "max_q_mvar"] = row["max_q_mvar"]
    net.gen.loc[i, "controllable"] = True # set to True, meaning they are dispatchable

    # Piecewise segments -- each segment [p_lo, p_hi, c] defines the marginal cost (Php/MWh) between two MW breakpoints
    segments = []
    for k in range(1, 4): # this only supports till 3 segments tho so adjust cguro if needed but i think 3 naman ung max?
        p_lo = f"p{2*k-1}"
        p_hi = f"p{2*k}"
        c    = f"c{k}"
        if p_lo in row and pd.notna(row[p_lo]):
            segments.append([float(row[p_lo]), float(row[p_hi]), float(row[c])])

    if not segments:
        raise ValueError(f"No PWL segments found for {name}")

    pp.create_pwl_cost(net, i, "gen", segments)

print("Generator PWL costs loaded")

# ------------------------------
# External grid PWL cost
# ------------------------------
for i in net.ext_grid.index:
    name = net.ext_grid.loc[i, "name"]

    if name not in ext_lookup:
        raise ValueError(f"Ext grid '{name}' not found in CSV")

    row = ext_lookup[name]

    pmin = float(row["min_p_mw"])
    pmax = float(row["max_p_mw"])
    cost = float(row["cost_php_per_mwh"])

    # pmin and pmax are estimated from the allowable MVA of the lines given in the SLD
    net.ext_grid.loc[i, "min_p_mw"] = pmin
    net.ext_grid.loc[i, "max_p_mw"] = pmax
    net.ext_grid.loc[i, "controllable"] = False # set to False if fixed as a slack and not considered dispatched by OPF

    # Flat marginal cost
    pp.create_pwl_cost(net, i, "ext_grid", [
        [pmin, pmax, cost]
    ]) # tried to not include the cost since it's not dispatched naman, but the cost here sets the price reference for the entire subgrid so without this all LMPs are zero

print("External grid cost loaded")

# ------------------------------
# Run OPF
# ------------------------------
# set verbose=True if we want to print the raw pypower results (ung may mahabang table), false if only the results specified below
pp.runopp(net, verbose=False)

print("\n OPF converged")

# ------------------------------
# Results
# ------------------------------
print("\n=== BUS LMP (₱/MWh) ===")
print(net.res_bus[["lam_p", "vm_pu"]]) # lam_p is LMP

print("\n=== GENERATOR DISPATCH ===")
gen_res = net.res_gen.copy()
gen_res["name"] = net.gen["name"].values
print(gen_res[["name", "p_mw", "q_mvar"]])

print("\n=== EXT GRID ===")
ext_res = net.res_ext_grid.copy()
ext_res["name"] = net.ext_grid["name"].values
print(ext_res)

print("\n=== TOTAL SYSTEM COST ===")
print(f"{net.res_cost:,.2f} ₱/hour")

# ------------------------------
# LOAD LMP
# ------------------------------
load_res = net.res_load.copy()
load_res["name"] = net.load["name"].values
load_res["bus"] = net.load["bus"].values
load_res["dispatch_mw"] = load_res["p_mw"]  # keep positive
load_res["lmp_php_mwh"] = load_res["bus"].apply(lambda b: net.res_bus.loc[b, "lam_p"])

load_table = load_res[["name", "bus", "dispatch_mw", "lmp_php_mwh"]]
load_table = load_table.rename(columns={
    "name": "Load",
    "bus": "Bus",
    "dispatch_mw": "Dispatch (MW)",
    "lmp_php_mwh": "LMP (₱/MWh)"
})
print("\n=== LOAD LMP TABLE ===")
print(load_table.to_string(index=False, justify="left", float_format="%.2f"))

# ------------------------------
# GENERATOR LMP
# ------------------------------
gen_res = net.res_gen.copy()
gen_res["name"] = net.gen["name"].values
gen_res["bus"]  = net.gen["bus"].values
gen_res["dispatch_mw"] = gen_res["p_mw"].abs()  # take absolute value
gen_res["lmp_php_mwh"] = gen_res["bus"].apply(lambda b: net.res_bus.loc[b, "lam_p"])

gen_table = gen_res[["name", "bus", "dispatch_mw", "lmp_php_mwh"]]
gen_table = gen_table.rename(columns={
    "name": "Generator",
    "bus": "Bus",
    "dispatch_mw": "Dispatch (MW)",
    "lmp_php_mwh": "LMP (₱/MWh)"})

print("\n=== GENERATOR LMP TABLE ===")
print(gen_table.to_string(index=False, justify="left", float_format="%.2f"))